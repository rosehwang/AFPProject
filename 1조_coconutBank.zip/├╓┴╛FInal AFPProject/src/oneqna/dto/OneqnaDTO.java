package oneqna.dto;

public class OneqnaDTO {

	private int no;
	private String writer;
	private String content;
	private String reg_date;
	private String admin_title;
	private String admin_regdate;
	private String admin_content;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public String getAdmin_title() {
		return admin_title;
	}
	public void setAdmin_title(String admin_title) {
		this.admin_title = admin_title;
	}
	public String getAdmin_regdate() {
		return admin_regdate;
	}
	public void setAdmin_regdate(String admin_regdate) {
		this.admin_regdate = admin_regdate;
	}
	public String getAdmin_content() {
		return admin_content;
	}
	public void setAdmin_content(String admin_content) {
		this.admin_content = admin_content;
	}




}
