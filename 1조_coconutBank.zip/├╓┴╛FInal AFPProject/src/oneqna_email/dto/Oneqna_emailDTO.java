package oneqna_email.dto;

public class Oneqna_emailDTO {
 
	private int no;
	private String writer;
	private String writer_title;
	private String writer_email;
	private String content;
	private String reg_date;
	private String admin_title;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWriter_title() {
		return writer_title;
	}
	public void setWriter_title(String writer_title) {
		this.writer_title = writer_title;
	}
	public String getWriter_email() {
		return writer_email;
	}
	public void setWriter_email(String writer_email) {
		this.writer_email = writer_email;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public String getAdmin_title() {
		return admin_title;
	}
	public void setAdmin_title(String admin_title) {
		this.admin_title = admin_title;
	}
	
	
	
	
}
