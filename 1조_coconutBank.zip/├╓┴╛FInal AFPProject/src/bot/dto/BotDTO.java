package bot.dto;

public class BotDTO {
	private int no;
	private String bot_no;
	private String bot_title;
	private String bot_content;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getBot_no() {
		return bot_no;
	}
	public void setBot_no(String bot_no) {
		this.bot_no = bot_no;
	}
	public String getBot_title() {
		return bot_title;
	}
	public void setBot_title(String bot_title) {
		this.bot_title = bot_title;
	}
	public String getBot_content() {
		return bot_content;
	}
	public void setBot_content(String bot_content) {
		this.bot_content = bot_content;
	}
	
	
}
