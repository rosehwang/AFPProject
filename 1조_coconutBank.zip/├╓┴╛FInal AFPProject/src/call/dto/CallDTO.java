package call.dto;

public class CallDTO {

	private int call_no;
	private String call_type;
	private String call_time;
	private String call_title;
	private String call_content;
	private String call_hp;
	private String call_writer;
	private String call_check;
	
	public String getCall_check() {
		return call_check;
	}
	public void setCall_check(String call_check) {
		this.call_check = call_check;
	}
	public int getCall_no() {
		return call_no;
	}
	public void setCall_no(int call_no) {
		this.call_no = call_no;
	}
	public String getCall_type() {
		return call_type;
	}
	public void setCall_type(String call_type) {
		this.call_type = call_type;
	}
	public String getCall_time() {
		return call_time;
	}
	public void setCall_time(String call_time) {
		this.call_time = call_time;
	}
	public String getCall_title() {
		return call_title;
	}
	public void setCall_title(String call_title) {
		this.call_title = call_title;
	}
	public String getCall_content() {
		return call_content;
	}
	public void setCall_content(String call_content) {
		this.call_content = call_content;
	}
	public String getCall_hp() {
		return call_hp;
	}
	public void setCall_hp(String call_hp) {
		this.call_hp = call_hp;
	}
	public String getCall_writer() {
		return call_writer;
	}
	public void setCall_writer(String call_writer) {
		this.call_writer = call_writer;
	}
	
	
	
	
}
