package news.dto;

public class NewsDTO {
	private int news_no;
	private String news_title;
	private String news_content;
	private String news_regdate;
	private int news_readcount;
	private int news_filesize;
	private String news_file;
	
	public int getNews_no() {
		return news_no;
	}
	public void setNews_no(int news_no) {
		this.news_no = news_no;
	}
	public String getNews_title() {
		return news_title;
	}
	public void setNews_title(String news_title) {
		this.news_title = news_title;
	}
	public String getNews_content() {
		return news_content;
	}
	public void setNews_content(String news_content) {
		this.news_content = news_content;
	}
	public String getNews_regdate() {
		return news_regdate;
	}
	public void setNews_regdate(String news_regdate) {
		this.news_regdate = news_regdate;
	}
	public int getNews_readcount() {
		return news_readcount;
	}
	public void setNews_readcount(int news_readcount) {
		this.news_readcount = news_readcount;
	}
	public int getNews_filesize() {
		return news_filesize;
	}
	public void setNews_filesize(int news_filesize) {
		this.news_filesize = news_filesize;
	}
	public String getNews_file() {
		return news_file;
	}
	public void setNews_file(String news_file) {
		this.news_file = news_file;
	}
	
	
	
	
}
