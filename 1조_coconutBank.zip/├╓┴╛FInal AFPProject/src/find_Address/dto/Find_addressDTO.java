package find_Address.dto;

public class Find_addressDTO {
	private int addr_no;
	private String find_address1;
	private String find_address2;
	private String find_postnum;
	
	public int getAddr_no() {
		return addr_no;
	}
	public void setAddr_no(int addr_no) {
		this.addr_no = addr_no;
	}
	public String getFind_address1() {
		return find_address1;
	}
	public void setFind_address1(String find_address1) {
		this.find_address1 = find_address1;
	}
	public String getFind_address2() {
		return find_address2;
	}
	public void setFind_address2(String find_address2) {
		this.find_address2 = find_address2;
	}
	public String getFind_postnum() {
		return find_postnum;
	}
	public void setFind_postnum(String find_postnum) {
		this.find_postnum = find_postnum;
	}
	
	
}
